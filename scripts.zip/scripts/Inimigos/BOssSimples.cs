using System.Collections;
using UnityEngine;

public class BOssSimples : MonoBehaviour
{
    public int attacksPerCombo = 3;     // Quantos ataques o boss faz antes de abrir o ataque musical
    public float delayBetweenAttacks = 1.5f;

    private int currentAttack = 0;
    private float attackTimer = 0f;

    public bool finishedCombo = false;   // O BossAttackCycle vai checar isso

    void Update()
    {
        attackTimer += Time.deltaTime;

        if (!finishedCombo && attackTimer >= delayBetweenAttacks)
        {
            DoBossAttack();
            attackTimer = 0f;
        }
    }

    public void DoBossAttack()
    {
        currentAttack++;
        Debug.Log("Boss atacou! Ataque n�mero: " + currentAttack);

        if (currentAttack >= attacksPerCombo)
        {
            finishedCombo = true;
            currentAttack = 0;
            Debug.Log("Boss terminou o combo. Jogador pode tentar o ataque musical.");
        }
    }

    public void ResetCombo()
    {
        finishedCombo = false;
        currentAttack = 0;
        attackTimer = 0f;
        Debug.Log("Boss reiniciou o combo.");
    }

}
