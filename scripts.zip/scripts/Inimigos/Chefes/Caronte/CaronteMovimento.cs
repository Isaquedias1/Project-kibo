using UnityEngine;
using UnityEngine.AI;

public class CaronteMovimento : MonoBehaviour
{
    public Transform[] pontosDePatrulha;
    private int indiceAtual = 0;
    private NavMeshAgent agent;
    public float velocidade = 20f;
    public float startWaitTime = 4;
    float m_WaitTime;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.SetDestination(pontosDePatrulha[indiceAtual].position);
        agent.speed = velocidade;
    }

    void Update()
    {
        Patroling();
    }

    private void Patroling()
    {

        agent.SetDestination(pontosDePatrulha[indiceAtual].position);
        agent.speed = velocidade;
        if (m_WaitTime <= 0)
        {
            NextPoint();
            m_WaitTime = startWaitTime;
        }
        else
        {
            m_WaitTime -= Time.deltaTime;
        }
    }

    public void NextPoint()
    {
        indiceAtual = (indiceAtual + 1) % pontosDePatrulha.Length;
        agent.SetDestination(pontosDePatrulha[indiceAtual].position);
    }
}
