using UnityEngine;

public class triggerBoss : MonoBehaviour
{
    // Arraste o objeto do inimigo (GameObject) para este campo no Inspector do Unity
    public GameObject objetoInimigo;
    private Vector3 posicao;

    // M�todo para desativar o inimigo
    public void DesativarInimigo()
    {
        if (objetoInimigo != null)
        {
            objetoInimigo.SetActive(false);
            // posicao(0, -15, 0);
            Debug.Log("Inimigo desativado!");
        }
    }

    // M�todo para ativar o inimigo
    public void OnCollisionEnter(Collision collision)
    {
        if (objetoInimigo != null)
        {
            objetoInimigo.SetActive(true);
            Debug.Log("Inimigo ativado!");
        }
    }
    /*public void AtivarInimigo()
    {
        if (objetoInimigo != null)
        {
            objetoInimigo.SetActive(true);
            Debug.Log("Inimigo ativado!");
        }
    }*/

    // Exemplo de uso com teclas (para testar)
    //void Update()
    /*{
        if (Input.GetKeyDown(KeyCode.D))
        {
            DesativarInimigo();
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            AtivarInimigo();
        }*/
    }
