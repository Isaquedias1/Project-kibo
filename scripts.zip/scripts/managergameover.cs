using UnityEngine;
using UnityEngine.SceneManagement;

public class managergameover : MonoBehaviour
{
    // Reinicia a cena atual
    public void RestartLevel()
    {
        Time.timeScale = 1f; // volta o tempo ao normal
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }

    // Vai para o menu principal (troque "menu" pelo nome da sua cena de menu)
    public void GoToMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("menu");
    }

    // Fecha o jogo (funciona em build)
    public void QuitGame()
    {
        Application.Quit();
    }
}

