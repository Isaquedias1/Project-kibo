using UnityEngine;
using UnityEngine.SceneManagement;

public class trocascriptsimples : MonoBehaviour
{
   

    // Carrega uma cena pelo �ndice (Build Index)
    public void LoadSceneByIndex(int index)
    {
        SceneManager.LoadScene(index);
    }
    private void OnTriggerEnter(Collider other) {

        SceneManager.LoadScene("cena07Sol"); 
    }
    
}
