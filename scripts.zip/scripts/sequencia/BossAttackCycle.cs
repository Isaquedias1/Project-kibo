using UnityEngine;

public class BossAttackCycle : MonoBehaviour
{
    public bool finishedCombo = false;        // Ativado quando o boss termina o ataque
    public MusicAttackManager music;          // Refer�ncia ao minigame musical

    private bool waitingForMusic = false;

    void Update()
    {
        // Exemplo simples: ao apertar B, simulamos que o boss terminou o combo
        if (Input.GetKeyDown(KeyCode.B))
        {
            finishedCombo = true;
        }

        // Quando o combo termina, liberamos a possibilidade do golpe musical
        if (finishedCombo && !waitingForMusic)
        {
            waitingForMusic = true;
            music.EnableMusicChance();
        }

        // Se o minigame terminar (acerto ou erro), o boss volta a atacar
        if (waitingForMusic && music.MinigameFinished)
        {
            waitingForMusic = false;
            finishedCombo = false;
        }
    }
}
