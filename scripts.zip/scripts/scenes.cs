using UnityEngine;
using UnityEngine.SceneManagement;

public class scenes : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {
        SceneManager.LoadScene("Cena3Mar");
    }
}
