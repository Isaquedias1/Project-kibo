using UnityEngine;

public class AtkFisico : MonoBehaviour
{
    public float attackRange = 2f;
    public int atqDano = 10;
    public Transform attackPoint;
    public LayerMask enemyLayers;
    public float Cooldown = 1f;

    private float proximoAtaque = 0f;

    void Update()
    {
        if (Time.time >= proximoAtaque)
        {
            if (Input.GetMouseButton(0))
            {
                Debug.Log("Bateu");
                Attack();
                proximoAtaque = Time.time + Cooldown;
            }
        }
    }

    void Attack()
    {
        Collider[] hitEnemies = Physics.OverlapSphere(attackPoint.position, attackRange, enemyLayers);

        foreach (Collider inimigo in hitEnemies)
        {
            Vidas vidaInimigo = inimigo.GetComponent<Vidas>();
            if (vidaInimigo != null)
            {
                vidaInimigo.TomarDano(atqDano);
                Debug.Log("Bateu no inimigo");
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}