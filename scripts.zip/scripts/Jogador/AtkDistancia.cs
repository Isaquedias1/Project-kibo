using System.Collections;
using UnityEngine;

public class AtkDistancia : MonoBehaviour
{
    public GameObject Flecha;
    //public GameObject Inimigo;
    public Transform pontoDisparo;
    public float Forca = 10f;  // Defina um valor padr�o de for�a
    public float Carregamento = 1f;  // Defina um valor padr�o de tempo de carregamento
    public float TempoDestruicaoFlecha = 5f; // Tempo para destruir a flecha ap�s disparo
    bool carregando = false;
    public float ArremessoUpwardForca;

    void Start()
    {

    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse1) && !carregando)
        {
            StartCoroutine(CarregarFlecha());
        }
    }

    IEnumerator CarregarFlecha()
    {
        carregando = true;
        Debug.Log("Carregando");
        yield return new WaitForSeconds(Carregamento);

        DispararFlecha();
        carregando = false;
    }

    void DispararFlecha()
    {
        if (Flecha != null && pontoDisparo != null)
        {
            // Instancia a flecha na posi��o do ponto de disparo
            GameObject Disparo = Instantiate(Flecha, pontoDisparo.position, pontoDisparo.rotation);

            // Obt�m o Rigidbody da flecha instanciada
            Rigidbody rb = Disparo.GetComponent<Rigidbody>();

            if (rb != null)
            {
                // Aplica for�a na flecha para ela ser disparada
                Vector3 forceToAdd = pontoDisparo.transform.forward * Forca + transform.up * ArremessoUpwardForca;
                rb.AddForce(forceToAdd, ForceMode.Impulse);
                Debug.Log("Flecha Disparada");

                // Chama a fun��o para destruir a flecha ap�s um tempo
                Destroy(Disparo, TempoDestruicaoFlecha);
            }
            else
            {
                Debug.LogWarning("A flecha n�o possui Rigidbody.");
            }
        }
        else
        {
            Debug.LogWarning("Flecha ou ponto de disparo n�o definidos.");
        }
    }
}
