using UnityEngine;

public class MusicOnbossfightEnter : MonoBehaviour
{
    public AudioSource audioSource; // Arraste o AudioSource aqui
    public bool playOnce = false;    // Se quiser que toque s� uma vez

    bool hasPlayed = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (playOnce)
            {
                if (!hasPlayed)
                {
                    audioSource.Play();
                    hasPlayed = true;
                }
            }
            else
            {
                audioSource.Play();
            }
        }
    }
}
